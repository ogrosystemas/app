/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: lupa_erp
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity` varchar(100) NOT NULL,
  `entity_id` varchar(36) DEFAULT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_value`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_entity` (`entity`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_audit_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_accounts`
--

DROP TABLE IF EXISTS `bank_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_accounts` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Ex: Conta BB, Caixa Loja, Cartão Inter',
  `type` enum('CORRENTE','POUPANCA','CAIXA','CARTAO_CREDITO','INVESTIMENTO') NOT NULL DEFAULT 'CORRENTE',
  `bank_name` varchar(60) DEFAULT NULL,
  `agency` varchar(20) DEFAULT NULL,
  `account_num` varchar(30) DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_accounts`
--

LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
INSERT INTO `bank_accounts` VALUES
('dfdc9aa0-3ce3-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','Conta Corrente Principal','CORRENTE','Banco do Brasil',NULL,NULL,5000.00,1,'2026-04-20 20:08:03'),
('dfdca2b4-3ce3-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','Caixa Físico','CAIXA',NULL,NULL,NULL,800.00,1,'2026-04-20 20:08:03'),
('dfdca40b-3ce3-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','Cartão de Crédito Empresarial','CARTAO_CREDITO','Nubank',NULL,NULL,0.00,1,'2026-04-20 20:08:03');
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_of_accounts`
--

DROP TABLE IF EXISTS `chart_of_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_of_accounts` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `code` varchar(20) NOT NULL COMMENT 'Ex: 3.1.1',
  `name` varchar(100) NOT NULL,
  `type` enum('RECEITA','DESPESA','CUSTO','ATIVO','PASSIVO','PATRIMONIO') NOT NULL,
  `subtype` varchar(50) DEFAULT NULL COMMENT 'Ex: OPERACIONAL, FINANCEIRA, ADMINISTRATIVA',
  `parent_id` varchar(36) DEFAULT NULL,
  `dre_line` varchar(50) DEFAULT NULL COMMENT 'Linha do DRE: RECEITA_BRUTA, CMV, etc.',
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code_tenant` (`tenant_id`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_of_accounts`
--

LOCK TABLES `chart_of_accounts` WRITE;
/*!40000 ALTER TABLE `chart_of_accounts` DISABLE KEYS */;
INSERT INTO `chart_of_accounts` VALUES
('e1e435f6-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3','RECEITAS','RECEITA',NULL,NULL,'RECEITA_BRUTA',1,'2026-04-20 19:53:47'),
('e1e43d7f-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.1','Receitas Operacionais','RECEITA','OPERACIONAL',NULL,'RECEITA_BRUTA',1,'2026-04-20 19:53:47'),
('e1e43f62-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.1.1','Vendas Marketplace ML','RECEITA','OPERACIONAL',NULL,'RECEITA_BRUTA',1,'2026-04-20 19:53:47'),
('e1e43fb4-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.1.2','Vendas Loja Própria','RECEITA','OPERACIONAL',NULL,'RECEITA_BRUTA',1,'2026-04-20 19:53:47'),
('e1e43fef-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.1.3','Vendas Atacado','RECEITA','OPERACIONAL',NULL,'RECEITA_BRUTA',1,'2026-04-20 19:53:47'),
('e1e4407f-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.2','Outras Receitas','RECEITA','NAO_OPERACIONAL',NULL,'OUTRAS_RECEITAS',1,'2026-04-20 19:53:47'),
('e1e440b8-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.2.1','Receitas Financeiras','RECEITA','FINANCEIRA',NULL,'RECEITAS_FINANCEIRAS',1,'2026-04-20 19:53:47'),
('e1e440ea-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.2.2','Venda de Ativo','RECEITA','NAO_OPERACIONAL',NULL,'OUTRAS_RECEITAS',1,'2026-04-20 19:53:47'),
('e1e44121-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.9','Deduções da Receita','DESPESA','DEDUCAO',NULL,'DEDUCOES',1,'2026-04-20 19:53:47'),
('e1e44154-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.9.1','Taxas Marketplace ML','DESPESA','DEDUCAO',NULL,'DEDUCOES',1,'2026-04-20 19:53:47'),
('e1e44182-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.9.2','Devoluções e Cancelamentos','DESPESA','DEDUCAO',NULL,'DEDUCOES',1,'2026-04-20 19:53:47'),
('e1e441b2-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','3.9.3','Impostos sobre Vendas','DESPESA','DEDUCAO',NULL,'DEDUCOES',1,'2026-04-20 19:53:47'),
('e1e441e0-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4','CUSTOS','CUSTO',NULL,NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e4421a-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4.1','Custo dos Produtos Vendidos','CUSTO','CMV',NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e4424b-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4.1.1','Custo de Mercadorias','CUSTO','CMV',NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e442cd-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4.1.2','Fretes de Compra','CUSTO','CMV',NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e44300-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4.2','Custos Logísticos','CUSTO','LOGISTICA',NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e4432e-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4.2.1','Fretes de Envio','CUSTO','LOGISTICA',NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e4435b-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','4.2.2','Embalagens','CUSTO','LOGISTICA',NULL,'CMV',1,'2026-04-20 19:53:47'),
('e1e44387-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5','DESPESAS OPERACIONAIS','DESPESA',NULL,NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e443b5-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.1','Despesas com Pessoal','DESPESA','PESSOAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e443e4-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.1.1','Salários e Pró-labore','DESPESA','PESSOAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44414-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.1.2','Encargos Trabalhistas','DESPESA','PESSOAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44444-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.1.3','Benefícios (VT, VR, Plano saúde)','DESPESA','PESSOAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44475-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2','Despesas Administrativas','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e444a4-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2.1','Aluguel','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e444d2-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2.2','Energia Elétrica','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44502-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2.3','Internet e Telefone','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44530-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2.5','Material de Escritório','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e4455f-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2.6','Contabilidade','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44588-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.3','Despesas de Marketing','DESPESA','MARKETING',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44609-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.3.1','Anúncios Patrocinados ML','DESPESA','MARKETING',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e4463e-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.3.2','Google Ads / Meta Ads','DESPESA','MARKETING',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e4466c-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.3.3','Fotografia de Produtos','DESPESA','MARKETING',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44699-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.4','Despesas com Sistemas e TI','DESPESA','TECNOLOGIA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e446c9-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.4.1','Sistema ERP-WMS','DESPESA','TECNOLOGIA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e446fa-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.4.2','Hospedagem e Domínio','DESPESA','TECNOLOGIA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e4472b-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.5','Despesas Financeiras','DESPESA','FINANCEIRA',NULL,'DESPESAS_FINANCEIRAS',1,'2026-04-20 19:53:47'),
('e1e4475d-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.5.1','Tarifas Bancárias','DESPESA','FINANCEIRA',NULL,'DESPESAS_FINANCEIRAS',1,'2026-04-20 19:53:47'),
('e1e44790-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.5.2','Juros e Multas','DESPESA','FINANCEIRA',NULL,'DESPESAS_FINANCEIRAS',1,'2026-04-20 19:53:47'),
('e1e447c2-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.5.3','IOF e Taxas de Cartão','DESPESA','FINANCEIRA',NULL,'DESPESAS_FINANCEIRAS',1,'2026-04-20 19:53:47'),
('e1e447f6-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.6','Impostos e Tributos','DESPESA','FISCAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44829-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.6.1','Simples Nacional / DAS','DESPESA','FISCAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44859-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.6.2','ICMS / ISS','DESPESA','FISCAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e44889-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.6.3','Pró-labore e INSS Sócio','DESPESA','FISCAL',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 19:53:47'),
('e1e448b5-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.9','Outras Despesas','DESPESA','OUTRAS',NULL,'OUTRAS_DESPESAS',1,'2026-04-20 19:53:47'),
('e1e448e4-3ce1-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.9.1','Despesas Diversas','DESPESA','OUTRAS',NULL,'OUTRAS_DESPESAS',1,'2026-04-20 19:53:47'),
('ff83b8ba-3cfe-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','5.2.4','Água e Saneamento','DESPESA','ADMINISTRATIVA',NULL,'DESPESAS_OPERACIONAIS',1,'2026-04-20 23:22:13');
/*!40000 ALTER TABLE `chart_of_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_entries`
--

DROP TABLE IF EXISTS `financial_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_entries` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `entry_date` date NOT NULL,
  `due_date` date DEFAULT NULL COMMENT 'Vencimento (contas a pagar/receber)',
  `paid_date` date DEFAULT NULL COMMENT 'Data do pagamento efetivo',
  `description` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `direction` enum('CREDIT','DEBIT') NOT NULL,
  `status` enum('PENDING','PAID','CANCELLED','OVERDUE') NOT NULL DEFAULT 'PAID',
  `account_id` varchar(36) DEFAULT NULL COMMENT 'FK bank_accounts',
  `coa_id` varchar(36) DEFAULT NULL COMMENT 'FK chart_of_accounts',
  `category` varchar(50) NOT NULL DEFAULT 'OPERATIONAL',
  `dre_category` varchar(50) DEFAULT NULL,
  `is_recurring` tinyint(4) NOT NULL DEFAULT 0,
  `recurrence_type` enum('MONTHLY','WEEKLY','YEARLY') DEFAULT NULL,
  `recurrence_end` date DEFAULT NULL,
  `parent_entry_id` varchar(36) DEFAULT NULL COMMENT 'Para lançamentos recorrentes',
  `order_id` varchar(36) DEFAULT NULL COMMENT 'FK orders (se veio de venda)',
  `notes` text DEFAULT NULL,
  `attachment_path` varchar(255) DEFAULT NULL COMMENT 'Comprovante/NF',
  `created_by` varchar(36) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tenant_date` (`tenant_id`,`entry_date`),
  KEY `idx_tenant_status` (`tenant_id`,`status`),
  KEY `idx_due_date` (`due_date`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_entries`
--

LOCK TABLES `financial_entries` WRITE;
/*!40000 ALTER TABLE `financial_entries` DISABLE KEYS */;
INSERT INTO `financial_entries` VALUES
('173afcc0-a089-4f19-b6a2-e8f24829aa9d','tenant-demo-0001-0000-000000000001','2026-04-20',NULL,'2026-04-20','balas',10.00,'DEBIT','PAID',NULL,'e1e448b5-3ce1-11f1-9148-00505662c0a1','OPERATIONAL','OUTRAS_DESPESAS',0,'MONTHLY',NULL,NULL,NULL,NULL,NULL,'f3a8d4af-3c7c-11f1-9148-00505662c0a1','2026-04-20 23:44:26'),
('7a1c5809-961b-496a-b842-b9aa81791252','tenant-demo-0001-0000-000000000001','2026-04-20',NULL,'2026-04-20','despesa agua',50.00,'DEBIT','PAID','dfdc9aa0-3ce3-11f1-9148-00505662c0a1','e1e44475-3ce1-11f1-9148-00505662c0a1','OPERATIONAL','DESPESAS_OPERACIONAIS',0,'MONTHLY',NULL,NULL,NULL,NULL,NULL,'f3a8d4af-3c7c-11f1-9148-00505662c0a1','2026-04-20 22:41:11');
/*!40000 ALTER TABLE `financial_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meli_accounts`
--

DROP TABLE IF EXISTS `meli_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meli_accounts` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `meli_user_id` varchar(50) NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `access_token_enc` text NOT NULL,
  `refresh_token_enc` text NOT NULL,
  `token_expires_at` datetime NOT NULL,
  `scopes` text DEFAULT NULL,
  `reputation_level` varchar(50) DEFAULT NULL,
  `sales_score` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_sync_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_meli_user` (`meli_user_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_meli_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meli_accounts`
--

LOCK TABLES `meli_accounts` WRITE;
/*!40000 ALTER TABLE `meli_accounts` DISABLE KEYS */;
INSERT INTO `meli_accounts` VALUES
('b1d51b1c-0db1-4ade-955a-8558ae27ed47','tenant-demo-0001-0000-000000000001','8031982','BUTOBARCELOS','tibabarcelos@gmail.com','APP_USR-7274929999947209-042017-505ad2c783f7b793c7db6c2720aa0d1f-8031982','TG-69e693d2b624960001a74850-8031982','2026-04-21 00:00:02',NULL,NULL,NULL,1,'2026-04-20 18:00:02','2026-04-20 19:17:28','2026-04-20 23:00:02'),
('meli-acc-0001-0000-000000000001','tenant-demo-0001-0000-000000000001','123456789','LOJA_ML_DEMO','loja@lojaml.com.br','demo_token_encrypted','demo_refresh_encrypted','2026-04-20 14:32:06',NULL,'platinum',98,0,'2026-04-20 08:32:06','2026-04-20 08:32:06','2026-04-20 19:16:28');
/*!40000 ALTER TABLE `meli_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `order_id` varchar(36) NOT NULL,
  `product_id` varchar(36) DEFAULT NULL,
  `meli_item_id` varchar(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `fk_items_product` (`product_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES
('a690d025-3c82-11f1-9148-00505662c0a1','order-001','prod-0001-0000-0000-000000000001','MLB1001','Fone Bluetooth Pro Max 50h',1,189.90,189.90,'FONE-BT-PRO'),
('a690da18-3c82-11f1-9148-00505662c0a1','order-002','prod-0003-0000-0000-000000000003','MLB1003','Cabo USB-C 2m Reforçado',1,34.90,34.90,'CABO-USBC-2M'),
('a690dbd8-3c82-11f1-9148-00505662c0a1','order-003','prod-0005-0000-0000-000000000005','MLB1005','Mouse Sem Fio Ergonomico',1,79.90,79.90,'MOUSE-ERGO-WL'),
('a690dc3b-3c82-11f1-9148-00505662c0a1','order-004','prod-0004-0000-0000-000000000004','MLB1004','Suporte Notebook Ajustavel',1,129.90,129.90,'SUPORTE-NB-ADJ'),
('a690dc94-3c82-11f1-9148-00505662c0a1','order-005','prod-0002-0000-0000-000000000002','MLB1002','Tela LCD 15 FHD',1,389.90,389.90,'TELA-15-FHD'),
('a690dce9-3c82-11f1-9148-00505662c0a1','order-006','prod-0006-0000-0000-000000000006','MLB1006','Teclado Mecanico RGB',1,249.90,249.90,'KBD-MECH-RGB'),
('a690dd36-3c82-11f1-9148-00505662c0a1','order-007','prod-0007-0000-0000-000000000007','MLB1007','Webcam Full HD 1080p',1,159.90,159.90,'WEBCAM-FHD-60'),
('a690dd84-3c82-11f1-9148-00505662c0a1','order-008','prod-0008-0000-0000-000000000008','MLB1008','Hub USB 7 Portas',1,89.90,89.90,'HUB-USB-7P'),
('a690ddda-3c82-11f1-9148-00505662c0a1','order-009','prod-0003-0000-0000-000000000003','MLB1003','Cabo USB-C 2m Reforçado',2,34.90,69.80,'CABO-USBC-2M'),
('a690de26-3c82-11f1-9148-00505662c0a1','order-010','prod-0001-0000-0000-000000000001','MLB1001','Fone Bluetooth Pro Max',1,189.90,189.90,'FONE-BT-PRO');
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `meli_account_id` varchar(36) NOT NULL,
  `meli_order_id` varchar(50) NOT NULL,
  `status` enum('PENDING','PAID','SHIPPED','DELIVERED','CANCELLED','RETURNED') NOT NULL DEFAULT 'PENDING',
  `substatus` varchar(50) DEFAULT NULL,
  `buyer_meli_id` varchar(50) NOT NULL,
  `buyer_nickname` varchar(100) NOT NULL,
  `buyer_first_name` varchar(100) DEFAULT NULL,
  `buyer_last_name` varchar(100) DEFAULT NULL,
  `buyer_email` varchar(255) DEFAULT NULL,
  `buyer_phone` varchar(30) DEFAULT NULL,
  `ship_street` varchar(255) DEFAULT NULL,
  `ship_number` varchar(20) DEFAULT NULL,
  `ship_city` varchar(100) DEFAULT NULL,
  `ship_state` varchar(50) DEFAULT NULL,
  `ship_zip` varchar(20) DEFAULT NULL,
  `ship_country` varchar(10) DEFAULT 'BR',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ml_fee_amount` decimal(10,2) DEFAULT NULL,
  `net_amount` decimal(10,2) DEFAULT NULL,
  `payment_status` enum('PENDING','APPROVED','REJECTED','IN_PROCESS','REFUNDED') NOT NULL DEFAULT 'PENDING',
  `payment_type` varchar(50) DEFAULT NULL,
  `installments` tinyint(4) DEFAULT 1,
  `ship_status` enum('PENDING','READY_TO_SHIP','SHIPPED','DELIVERED','RETURNED','NOT_DELIVERED') NOT NULL DEFAULT 'PENDING',
  `tracking_number` varchar(100) DEFAULT NULL,
  `label_url` varchar(500) DEFAULT NULL,
  `label_printed` tinyint(1) NOT NULL DEFAULT 0,
  `pdf_printed` tinyint(1) NOT NULL DEFAULT 0,
  `zpl_printed` tinyint(1) NOT NULL DEFAULT 0,
  `shipped_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `meli_ship_id` varchar(50) DEFAULT NULL,
  `has_mediacao` tinyint(1) NOT NULL DEFAULT 0,
  `idempotency_key` varchar(128) NOT NULL,
  `notes` text DEFAULT NULL,
  `order_date` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nf_path` varchar(255) DEFAULT NULL COMMENT 'Caminho local da NF salva',
  `nf_number` varchar(50) DEFAULT NULL COMMENT 'Número da NF',
  `nf_key` varchar(50) DEFAULT NULL COMMENT 'Chave da NF',
  `nf_fetched_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_meli_order` (`meli_order_id`),
  UNIQUE KEY `uk_idempotency` (`idempotency_key`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_ship_status` (`ship_status`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_has_mediacao` (`has_mediacao`),
  KEY `fk_orders_account` (`meli_account_id`),
  CONSTRAINT `fk_orders_account` FOREIGN KEY (`meli_account_id`) REFERENCES `meli_accounts` (`id`),
  CONSTRAINT `fk_orders_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
('order-001','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00891','PAID',NULL,'buyer001','carlos.melo22','Carlos','Melo','carlos@email.com',NULL,'Rua das Flores 123',NULL,'São Paulo','SP','01310-100','BR',189.90,26.59,163.31,'APPROVED',NULL,1,'READY_TO_SHIP',NULL,NULL,0,0,0,NULL,NULL,NULL,0,'idem-001',NULL,'2026-04-19 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-002','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00889','PAID',NULL,'buyer002','ana.sousa99','Ana','Sousa','ana@email.com',NULL,'Av Paulista 1000',NULL,'São Paulo','SP','01310-200','BR',34.90,5.58,29.32,'APPROVED',NULL,1,'SHIPPED',NULL,NULL,1,1,1,NULL,NULL,NULL,0,'idem-002',NULL,'2026-04-18 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-003','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00887','PAID',NULL,'buyer003','pedro.lima55','Pedro','Lima','pedro@email.com',NULL,'Rua XV de Novembro 50',NULL,'Curitiba','PR','80020-310','BR',79.90,11.19,68.71,'APPROVED',NULL,1,'READY_TO_SHIP',NULL,NULL,1,1,1,NULL,NULL,NULL,0,'idem-003',NULL,'2026-04-18 08:32:06','2026-04-20 08:32:06','2026-04-20 08:39:12',NULL,NULL,NULL,NULL),
('order-004','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00883','PAID',NULL,'buyer004','maria.oliveira3','Maria','Oliveira','maria@email.com',NULL,'Rua Dom Pedro II 200',NULL,'Belo Horizonte','MG','30110-012','BR',129.90,18.19,111.71,'APPROVED',NULL,1,'READY_TO_SHIP',NULL,NULL,0,0,0,NULL,NULL,NULL,0,'idem-004',NULL,'2026-04-17 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-005','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00871','PAID',NULL,'buyer005','joao.costa77','João','Costa','joao@email.com',NULL,'Av Beira Mar 500',NULL,'Florianópolis','SC','88015-200','BR',389.90,54.59,335.31,'APPROVED',NULL,1,'READY_TO_SHIP',NULL,NULL,0,0,0,NULL,NULL,NULL,1,'idem-005',NULL,'2026-04-16 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-006','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00865','PAID',NULL,'buyer006','lucia.fernandes','Lucia','Fernandes','lucia@email.com',NULL,'Rua Liberdade 88',NULL,'São Paulo','SP','01503-010','BR',249.90,34.99,214.91,'APPROVED',NULL,1,'DELIVERED',NULL,NULL,1,1,1,NULL,NULL,NULL,0,'idem-006',NULL,'2026-04-15 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-007','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00860','PAID',NULL,'buyer007','roberto.silva11','Roberto','Silva','roberto@email.com',NULL,'Av Atlantica 1800',NULL,'Rio de Janeiro','RJ','22021-001','BR',159.90,22.39,137.51,'APPROVED',NULL,1,'SHIPPED',NULL,NULL,1,1,1,NULL,NULL,NULL,0,'idem-007',NULL,'2026-04-14 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-008','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00855','PAID',NULL,'buyer008','fernanda.gomes','Fernanda','Gomes','fernanda@email.com',NULL,'Rua Augusta 300',NULL,'São Paulo','SP','01305-000','BR',89.90,12.59,77.31,'APPROVED',NULL,1,'READY_TO_SHIP',NULL,NULL,0,0,0,NULL,NULL,NULL,0,'idem-008',NULL,'2026-04-19 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-009','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00848','PAID',NULL,'buyer009','thiago.mendes22','Thiago','Mendes','thiago@email.com',NULL,'Rua Conceicao 450',NULL,'Campinas','SP','13010-050','BR',34.90,5.58,29.32,'APPROVED',NULL,1,'DELIVERED',NULL,NULL,1,1,1,NULL,NULL,NULL,0,'idem-009',NULL,'2026-04-13 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL),
('order-010','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','#00840','PAID',NULL,'buyer010','patricia.souza','Patricia','Souza','pat@email.com',NULL,'Av Brasil 2000',NULL,'Porto Alegre','RS','90010-170','BR',189.90,26.59,163.31,'APPROVED',NULL,1,'READY_TO_SHIP',NULL,NULL,0,0,0,NULL,NULL,NULL,0,'idem-010',NULL,'2026-04-20 08:32:06','2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `meli_item_id` varchar(50) DEFAULT NULL,
  `sku` varchar(100) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cost_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ml_fee_percent` decimal(5,2) NOT NULL DEFAULT 14.00,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `stock_min` int(11) NOT NULL DEFAULT 5,
  `stock_location` varchar(100) DEFAULT NULL,
  `ml_status` enum('ACTIVE','PAUSED','UNDER_REVIEW','CLOSED','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `ml_health` tinyint(4) DEFAULT NULL,
  `ml_conversion` decimal(5,2) DEFAULT NULL,
  `ml_visits` int(11) DEFAULT 0,
  `image_urls` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`image_urls`)),
  `is_free_shipping` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `picture_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`picture_ids`)),
  `ml_attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ml_attributes`)),
  `listing_type_id` varchar(30) NOT NULL DEFAULT 'gold_special',
  `catalog_product_id` varchar(50) DEFAULT NULL,
  `ml_permalink` varchar(255) DEFAULT NULL,
  `gtin` varchar(20) DEFAULT NULL,
  `item_condition` varchar(10) NOT NULL DEFAULT 'new',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_sku` (`tenant_id`,`sku`),
  UNIQUE KEY `uk_meli_item` (`meli_item_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_products_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
('prod-0001-0000-0000-000000000001','tenant-demo-0001-0000-000000000001','MLB1001','FONE-BT-PRO','Fone Bluetooth Pro Max 50h','Fone de ouvido bluetooth com cancelamento de ruido ativo, 50h de bateria',NULL,189.90,72.00,14.00,47,10,NULL,'ACTIVE',90,5.20,3240,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0002-0000-0000-000000000002','tenant-demo-0001-0000-000000000001','MLB1002','TELA-15-FHD','Tela LCD 15 FHD para Notebook','Tela LCD Full HD 15 polegadas para notebook, compativel com varios modelos',NULL,389.90,195.00,14.00,23,5,NULL,'ACTIVE',55,2.10,890,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0003-0000-0000-000000000003','tenant-demo-0001-0000-000000000001','MLB1003','CABO-USBC-2M','Cabo USB-C 2m Reforçado Carga Rapida','Cabo USB-C trancado 2 metros com carga rapida 65W',NULL,34.90,8.00,16.00,210,30,NULL,'ACTIVE',95,7.80,8100,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0004-0000-0000-000000000004','tenant-demo-0001-0000-000000000001','MLB1004','SUPORTE-NB-ADJ','Suporte Notebook Ajustavel Ergonomico','Suporte ergonomico ajustavel em aluminio para notebook ate 17 polegadas',NULL,129.90,48.00,14.00,3,5,NULL,'ACTIVE',30,1.80,420,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0005-0000-0000-000000000005','tenant-demo-0001-0000-000000000001','MLB1005','MOUSE-ERGO-WL','Mouse Sem Fio Ergonomico 2.4GHz','Mouse sem fio ergonomico com receptor USB, ate 30 dias de bateria',NULL,79.90,26.00,14.00,88,15,NULL,'ACTIVE',75,4.50,4680,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0006-0000-0000-000000000006','tenant-demo-0001-0000-000000000001','MLB1006','KBD-MECH-RGB','Teclado Mecanico RGB Switch Blue','Teclado mecanico com switches blue, retroiluminacao RGB e layout ABNT2',NULL,249.90,98.00,14.00,31,8,NULL,'ACTIVE',82,3.90,2100,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0007-0000-0000-000000000007','tenant-demo-0001-0000-000000000001','MLB1007','WEBCAM-FHD-60','Webcam Full HD 1080p 60fps Autofoco','Webcam profissional com autofoco e microfone embutido para home office',NULL,159.90,58.00,14.00,19,5,NULL,'ACTIVE',68,3.20,1560,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new'),
('prod-0008-0000-0000-000000000008','tenant-demo-0001-0000-000000000001','MLB1008','HUB-USB-7P','Hub USB 7 Portas USB 3.0 com Fonte','Hub USB 3.0 com 7 portas e fonte de alimentacao independente',NULL,89.90,32.00,14.00,54,10,NULL,'PAUSED',45,2.80,980,NULL,0,'2026-04-20 08:32:06','2026-04-20 08:32:06',NULL,NULL,'gold_special',NULL,NULL,NULL,'new');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue_jobs`
--

DROP TABLE IF EXISTS `queue_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue_jobs` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `meli_account_id` varchar(36) DEFAULT NULL,
  `topic` varchar(50) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT 2,
  `job_type` varchar(50) DEFAULT 'webhook',
  `status` enum('PENDING','PROCESSING','DONE','FAILED','RUNNING','COMPLETED','RETRYING') NOT NULL DEFAULT 'PENDING',
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`result`)),
  `error` text DEFAULT NULL,
  `attempts` tinyint(4) NOT NULL DEFAULT 0,
  `max_retries` tinyint(4) NOT NULL DEFAULT 3,
  `run_at` datetime NOT NULL DEFAULT current_timestamp(),
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `error_message` text DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idempotency_key` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_status` (`status`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_status_priority` (`status`,`priority`,`created_at`),
  KEY `idx_idem_key` (`idempotency_key`),
  KEY `idx_tenant_status` (`tenant_id`,`status`),
  CONSTRAINT `fk_jobs_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue_jobs`
--

LOCK TABLES `queue_jobs` WRITE;
/*!40000 ALTER TABLE `queue_jobs` DISABLE KEYS */;
INSERT INTO `queue_jobs` VALUES
('33a59f46-8d27-41c7-b986-8ce3cef88216','tenant-demo-0001-0000-000000000001','b1d51b1c-0db1-4ade-955a-8558ae27ed47','orders_v2','/orders/123456789',10,'webhook','FAILED','{\"topic\":\"orders_v2\",\"resource\":\"/orders/123456789\",\"user_id\":\"8031982\",\"application_id\":\"7274929999947209\",\"attempts\":1}',NULL,NULL,3,3,'2026-04-20 19:31:09',NULL,NULL,'2026-04-20 19:31:09','Empty order data','2026-04-20 14:34:01','bc7fa1cd967b49c9ee1ad4f65d42a38aba95d2da0aa9b040785f30003b8d7a5b'),
('d7170a48-0947-4f92-8e03-b976f51976f7','tenant-demo-0001-0000-000000000001','b1d51b1c-0db1-4ade-955a-8558ae27ed47','orders_v2','/orders/123456789',10,'webhook','FAILED','{\n    \"topic\": \"orders_v2\",\n    \"resource\": \"/orders/123456789\",\n    \"user_id\": \"8031982\",\n    \"application_id\": \"7274929999947209\",\n    \"attempts\": 1\n  }',NULL,NULL,3,3,'2026-04-20 19:27:31',NULL,NULL,'2026-04-20 19:27:31','Empty order data','2026-04-20 14:32:01','bc7fa1cd967b49c9ee1ad4f65d42a38aba95d2da0aa9b040785f30003b8d7a5b');
/*!40000 ALTER TABLE `queue_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sac_conversations`
--

DROP TABLE IF EXISTS `sac_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sac_conversations` (
  `id` varchar(36) NOT NULL,
  `tenant_id` varchar(36) NOT NULL,
  `order_id` varchar(36) NOT NULL,
  `status` enum('OPEN','WAITING','RESOLVED') NOT NULL DEFAULT 'OPEN',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sac_conversations`
--

LOCK TABLES `sac_conversations` WRITE;
/*!40000 ALTER TABLE `sac_conversations` DISABLE KEYS */;
INSERT INTO `sac_conversations` VALUES
('174cf30f-0221-43da-b909-43656b6ebab5','tenant-demo-0001-0000-000000000001','order-003','OPEN','2026-04-20 09:52:22'),
('6e9496ae-52b1-44ed-ba16-b04ed865ef9f','tenant-demo-0001-0000-000000000001','order-007','RESOLVED','2026-04-20 12:48:44'),
('74f7a7c1-f6c0-4163-99a3-11f684f03e4d','tenant-demo-0001-0000-000000000001','order-005','WAITING','2026-04-20 12:25:51');
/*!40000 ALTER TABLE `sac_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sac_messages`
--

DROP TABLE IF EXISTS `sac_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sac_messages` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `meli_account_id` varchar(36) NOT NULL,
  `order_id` varchar(36) DEFAULT NULL,
  `meli_pack_id` varchar(50) DEFAULT NULL,
  `meli_message_id` varchar(50) DEFAULT NULL,
  `from_role` enum('BUYER','SELLER','MELI_SYSTEM') NOT NULL,
  `from_nickname` varchar(100) NOT NULL,
  `from_meli_id` varchar(50) DEFAULT NULL,
  `message_text` text NOT NULL,
  `attachment_urls` longtext DEFAULT NULL CHECK (json_valid(`attachment_urls`)),
  `sentiment_score` float DEFAULT NULL,
  `sentiment_label` enum('VERY_NEGATIVE','NEGATIVE','NEUTRAL','POSITIVE','VERY_POSITIVE') DEFAULT NULL,
  `ai_suggestion` text DEFAULT NULL,
  `ai_used` tinyint(1) NOT NULL DEFAULT 0,
  `is_mediacao` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `conv_status` enum('OPEN','WAITING','RESOLVED') NOT NULL DEFAULT 'OPEN',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_meli_msg` (`meli_message_id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `fk_sac_account` (`meli_account_id`),
  CONSTRAINT `fk_sac_account` FOREIGN KEY (`meli_account_id`) REFERENCES `meli_accounts` (`id`),
  CONSTRAINT `fk_sac_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sac_messages`
--

LOCK TABLES `sac_messages` WRITE;
/*!40000 ALTER TABLE `sac_messages` DISABLE KEYS */;
INSERT INTO `sac_messages` VALUES
('a693d4c6-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-005','pack-001',NULL,'BUYER','joao.costa77','buyer005','Boa tarde! Meu pedido ainda nao foi enviado e ja faz 4 dias. Podem verificar o que houve? Estou muito preocupado.',NULL,-0.7,'NEGATIVE',NULL,0,0,1,'OPEN','2026-04-20 06:32:06'),
('a693e3ed-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-005','pack-001',NULL,'BUYER','joao.costa77','buyer005','Alguem pode me responder? Preciso saber o status do produto urgente pois e um presente!',NULL,-0.9,'VERY_NEGATIVE',NULL,0,0,1,'OPEN','2026-04-20 07:32:06'),
('a693e5f3-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-001','pack-002',NULL,'BUYER','carlos.melo22','buyer001','Ola, quando meu produto vai chegar? Fiz o pedido ontem.',NULL,-0.2,'NEUTRAL',NULL,0,0,1,'OPEN','2026-04-20 05:32:06'),
('a693e6b3-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-003','pack-003',NULL,'BUYER','pedro.lima55','buyer003','O mouse chegou mas nao esta funcionando direito. O scroll esta com problema. Podem me ajudar?',NULL,-0.6,'NEGATIVE',NULL,0,0,1,'OPEN','2026-04-20 03:32:06'),
('a693e74b-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-006','pack-004',NULL,'BUYER','lucia.fernandes','buyer006','Produto chegou perfeito! Qualidade excelente, muito satisfeita com a compra. Recomendo!',NULL,0.95,'VERY_POSITIVE',NULL,0,0,1,'OPEN','2026-04-19 08:32:06'),
('a693e845-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-006','pack-004',NULL,'SELLER','LOJA_ML_DEMO',NULL,'Que otimo! Ficamos muito felizes que gostou. Qualquer duvida estamos a disposicao!',NULL,0.9,'POSITIVE',NULL,0,0,1,'OPEN','2026-04-19 09:32:06'),
('a693e8db-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-007','pack-005',NULL,'BUYER','roberto.silva11','buyer007','Boa tarde, voces tem nota fiscal? Preciso para reembolso na empresa.',NULL,0.1,'NEUTRAL',NULL,0,0,1,'OPEN','2026-04-18 08:32:06'),
('a693e965-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-007','pack-005',NULL,'SELLER','LOJA_ML_DEMO',NULL,'Ola Roberto! Sim, a NF segue em anexo no pedido. Qualquer duvida e so chamar!',NULL,0.7,'POSITIVE',NULL,0,0,1,'OPEN','2026-04-18 09:32:06'),
('b8c46164-2fcd-45ab-8b96-327560773f75','tenant-demo-0001-0000-000000000001','meli-acc-0001-0000-000000000001','order-005',NULL,NULL,'SELLER','Administrador',NULL,'Compreendo a urgência por ser um presente. Estou verificando o status do seu pedido agora mesmo e já te informo.',NULL,NULL,NULL,NULL,0,0,1,'OPEN','2026-04-20 12:25:51');
/*!40000 ALTER TABLE `sac_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `user_id` varchar(36) NOT NULL,
  `token` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token` (`token`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('5e954053-6f74-4dec-a8b2-715531f7d6b2','f3a8d4af-3c7c-11f1-9148-00505662c0a1','fed32f53a8eb37aa68aa1d96170b6812102132550c5cbf7b879c113b697a00b5','170.82.179.210',NULL,'2026-04-20 21:49:48','2026-04-20 18:49:48'),
('5f5bfbd8-2541-4e4d-aa29-b759dbb2fa44','f3a8d4af-3c7c-11f1-9148-00505662c0a1','d764a5a68e22ed191ebbaac8cbbd181a8370f851844149a1e1bfc9e09327f729','201.131.156.14',NULL,'2026-04-20 11:25:19','2026-04-20 08:25:19'),
('6bac170f-bf79-40ec-8e67-dac46dcc6f7d','f3a8d4af-3c7c-11f1-9148-00505662c0a1','f2358c76c700155f74a54df103f3dc36c5d23313f8005f351c4739ed000d1086','201.131.156.14',NULL,'2026-04-20 11:38:33','2026-04-20 08:38:33'),
('997a8f1c-6f3f-4666-ac95-f49977a46fab','f3a8d4af-3c7c-11f1-9148-00505662c0a1','996a949e1bb56f4fd5ac68a1cff5784a92213cdf4de55a2803b5b2c224f42f71','170.82.179.210',NULL,'2026-04-21 02:30:17','2026-04-20 23:30:17'),
('baba3ec0-eaed-413d-9483-db3ff0508df6','f3a8d4af-3c7c-11f1-9148-00505662c0a1','38961247bb40794d9ae474ce6456ad15242956b519a137b4379905af4eeeaac6','170.82.179.210',NULL,'2026-04-21 01:33:10','2026-04-20 22:33:10'),
('c7e5d322-1c54-46ef-8799-55b9de2236c6','f3a8d4af-3c7c-11f1-9148-00505662c0a1','eb4df0bfb48770b70a4b879bc7f038d4260ecc8b40af7a8ced5f66e32597a34c','201.131.156.14',NULL,'2026-04-20 15:09:40','2026-04-20 12:09:40'),
('f6410cf0-01c6-405b-807b-b517c35e8705','f3a8d4af-3c7c-11f1-9148-00505662c0a1','51c651f4bef5965d6f29a8f6cbc5a35e6764f75fb413cba4f7572d3bd6bb9ed0','170.82.179.210',NULL,'2026-04-21 00:58:43','2026-04-20 21:58:43');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_settings`
--

DROP TABLE IF EXISTS `tenant_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_settings` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_key` (`tenant_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_settings`
--

LOCK TABLES `tenant_settings` WRITE;
/*!40000 ALTER TABLE `tenant_settings` DISABLE KEYS */;
INSERT INTO `tenant_settings` VALUES
('8111d86b-2ac4-4fae-a2db-6685f1cee6da','tenant-demo-0001-0000-000000000001','meli_app_id','7274929999947209','2026-04-20 19:16:07'),
('cce8ba1e-f92c-4951-af79-a4de9c52447c','tenant-demo-0001-0000-000000000001','meli_client_secret','oqIcOnIdUJNtXPQRF9FLz4SPiRcgesjA','2026-04-20 19:16:07');
/*!40000 ALTER TABLE `tenant_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenants` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `name` varchar(255) NOT NULL,
  `cnpj` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `license_key` varchar(512) NOT NULL,
  `license_status` enum('ACTIVE','EXPIRED','SUSPENDED','TRIAL') NOT NULL DEFAULT 'TRIAL',
  `license_expiry` datetime NOT NULL,
  `plan` enum('BASIC','PRO','ENTERPRISE') NOT NULL DEFAULT 'BASIC',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cnpj` (`cnpj`),
  UNIQUE KEY `uk_email` (`email`),
  UNIQUE KEY `uk_license` (`license_key`),
  KEY `idx_license_status` (`license_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES
('tenant-demo-0001-0000-000000000001','Loja Demo Mercado Livre','00.000.000/0001-00','admin@lojaml.com.br','DEMO-LICENSE-PLACEHOLDER','ACTIVE','2027-04-20 05:51:18','PRO','2026-04-20 05:51:18','2026-04-20 05:51:18');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `order_id` varchar(36) DEFAULT NULL,
  `product_id` varchar(36) DEFAULT NULL,
  `type` enum('SALE','REFUND','ML_FEE','SHIPPING_FEE','ADVERTISING','SUBSCRIPTION','MANUAL_ADJUSTMENT') NOT NULL,
  `category` enum('REVENUE','COST_OF_GOODS','MARKETPLACE_FEE','LOGISTICS','OPERATIONAL','FINANCIAL') NOT NULL,
  `description` varchar(500) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `direction` enum('CREDIT','DEBIT') NOT NULL,
  `meli_movement_id` varchar(50) DEFAULT NULL,
  `dre_category` enum('RECEITA_BRUTA','DEDUCOES','RECEITA_LIQUIDA','CMV','LUCRO_BRUTO','DESPESAS_OPERACIONAIS','EBITDA','LUCRO_LIQUIDO') DEFAULT NULL,
  `reference_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_meli_movement` (`meli_movement_id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_reference_date` (`reference_date`),
  KEY `idx_type` (`type`),
  CONSTRAINT `fk_trans_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES
('a69803ef-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','order-006',NULL,'SALE','REVENUE','Venda #00865 — Teclado Mecanico RGB',249.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-15','2026-04-20 08:32:06'),
('a6980f7e-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','order-006',NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00865',34.99,'DEBIT',NULL,'DEDUCOES','2026-04-15','2026-04-20 08:32:06'),
('a69810e4-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','order-007',NULL,'SALE','REVENUE','Venda #00860 — Webcam Full HD',159.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-14','2026-04-20 08:32:06'),
('a698116a-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','order-007',NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00860',22.39,'DEBIT',NULL,'DEDUCOES','2026-04-14','2026-04-20 08:32:06'),
('a69811df-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','order-009',NULL,'SALE','REVENUE','Venda #00848 — Cabo USB-C x2',69.80,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-13','2026-04-20 08:32:06'),
('a6981258-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','order-009',NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00848',11.17,'DEBIT',NULL,'DEDUCOES','2026-04-13','2026-04-20 08:32:06'),
('a69812c4-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'SALE','REVENUE','Venda #00841 — Mouse Sem Fio',79.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-12','2026-04-20 08:32:06'),
('a6981395-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00841',11.19,'DEBIT',NULL,'DEDUCOES','2026-04-12','2026-04-20 08:32:06'),
('a698140a-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'SALE','REVENUE','Venda #00835 — Fone Bluetooth Pro',189.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-11','2026-04-20 08:32:06'),
('a698146a-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00835',26.59,'DEBIT',NULL,'DEDUCOES','2026-04-11','2026-04-20 08:32:06'),
('a69814d1-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'SALE','REVENUE','Venda #00830 — Hub USB 7 Portas',89.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-10','2026-04-20 08:32:06'),
('a6981537-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00830',12.59,'DEBIT',NULL,'DEDUCOES','2026-04-10','2026-04-20 08:32:06'),
('a69815a2-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'MANUAL_ADJUSTMENT','COST_OF_GOODS','CMV — produtos vendidos no mes',312.00,'DEBIT',NULL,'CMV','2026-04-20','2026-04-20 08:32:06'),
('a6981668-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'SUBSCRIPTION','OPERATIONAL','Mensalidade Lupa ERP',149.90,'DEBIT',NULL,'DESPESAS_OPERACIONAIS','2026-04-20','2026-04-20 08:32:06'),
('a698175a-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'ADVERTISING','OPERATIONAL','Anuncios patrocinados ML — Abril',89.00,'DEBIT',NULL,'DESPESAS_OPERACIONAIS','2026-04-20','2026-04-20 08:32:06'),
('a6981846-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'SALE','REVENUE','Venda #00820 — Suporte Notebook',129.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-17','2026-04-20 08:32:06'),
('a69818b2-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00820',18.19,'DEBIT',NULL,'DEDUCOES','2026-04-17','2026-04-20 08:32:06'),
('a698191b-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'SALE','REVENUE','Venda #00815 — Teclado Mecanico',249.90,'CREDIT',NULL,'RECEITA_BRUTA','2026-04-16','2026-04-20 08:32:06'),
('a698197e-3c82-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001',NULL,NULL,'ML_FEE','MARKETPLACE_FEE','Taxa ML #00815',34.99,'DEBIT',NULL,'DEDUCOES','2026-04-16','2026-04-20 08:32:06');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `tenant_id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('SUPER_ADMIN','ADMIN','MANAGER','OPERATOR','VIEWER') NOT NULL DEFAULT 'OPERATOR',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `can_access_sac` tinyint(1) NOT NULL DEFAULT 0,
  `can_access_anuncios` tinyint(1) NOT NULL DEFAULT 0,
  `can_access_financeiro` tinyint(1) NOT NULL DEFAULT 0,
  `can_access_logistica` tinyint(1) NOT NULL DEFAULT 0,
  `can_access_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_email` (`tenant_id`,`email`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_users_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
('f3a8d4af-3c7c-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','admin@lojaml.com.br','Administrador','$2y$10$lfmfMfbDznHzgJ/.mnrUMuTBEfZhw96qlvCVk7dYXfo.KtSkjFVLe','ADMIN',1,'2026-04-20 18:30:17',1,1,1,1,1,'2026-04-20 05:51:18','2026-04-21 00:15:30'),
('f3a8e077-3c7c-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','sac@lojaml.com.br','Maria Silva (SAC)','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','OPERATOR',1,NULL,1,0,0,0,0,'2026-04-20 05:51:18','2026-04-20 08:32:06'),
('f3a8e3e9-3c7c-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','vendas@lojaml.com.br','Roberto Neto (Vendas)','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','MANAGER',1,NULL,0,1,0,0,0,'2026-04-20 05:51:18','2026-04-20 08:32:06'),
('f3a8e509-3c7c-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','financeiro@lojaml.com.br','Carla Dias (Financeiro)','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','OPERATOR',1,NULL,0,0,1,0,0,'2026-04-20 05:51:18','2026-04-20 08:32:06'),
('f3a8e64f-3c7c-11f1-9148-00505662c0a1','tenant-demo-0001-0000-000000000001','expedicao@lojaml.com.br','Lucas Moura (Expedicao)','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','OPERATOR',1,NULL,0,0,0,1,0,'2026-04-20 05:51:18','2026-04-20 08:32:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'lupa_erp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-20 22:16:34
